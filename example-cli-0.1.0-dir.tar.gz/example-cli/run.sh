#!/bin/bash

echo "running command $HELM_PLUGIN_NAME with subcommand $1 and args ${@:2}"
